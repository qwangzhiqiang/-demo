var siteinfo = {
  "name": 'pig_joke',
  "uniacid": "5",
  "acid": "5",
  "multiid": "0",
  "version": "1.0.0",
  "siteroot": "https://minbang.bendilaosiji.com/app/index.php",
  'method_design': '3'
};
module.exports = siteinfo;

