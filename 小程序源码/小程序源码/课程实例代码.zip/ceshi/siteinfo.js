var siteinfo = {
  "name": 'we7_wxappdemo',
  "uniacid": "3",
  "acid": "3",
  "multiid": "0",
  "version": "1.0.0",
  "siteroot": "http://ke.bendilaosiji.com/app/index.php",
  'method_design': '3'
};
module.exports = siteinfo;    

