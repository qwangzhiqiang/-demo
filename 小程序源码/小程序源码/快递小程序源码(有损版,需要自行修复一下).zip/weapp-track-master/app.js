//app.js
App({
    globalData: {
        mockData: true
    }
})