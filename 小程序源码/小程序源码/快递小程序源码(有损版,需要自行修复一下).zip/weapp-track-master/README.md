# 微信小程序－国际包裹查询工具

### 说明：

实现快递查询显示功能。

### 数据接口:

- https://api.getweapp.com/vendor/express

### 目录结构：

- assets — 存放项目图片文件
- pages — 存放项目页面文件
- utils — 存放格式化文件

### 开发环境：

微信web开发者工具 v0.11.122100

### 项目截图：

https://www.getweapp.com/project?projectId=5891e9d352e1e8733dc567e4

### 感谢：

本项目原始版本由dushouke提供：https://github.com/dushouke/wxapp-track