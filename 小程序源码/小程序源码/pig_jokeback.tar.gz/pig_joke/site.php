<?php
/**
 * pig_joke模块微站定义
 *
 * @author bendilaosiji
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Pig_jokeModuleSite extends WeModuleSite {


	public function doWebJoke() {
		//笑话列表
		global $_W,$_GPC;
				$sql="select * from ".tablename(pig_joke_article);	
                $sources=pdo_fetchall($sql);
                //分页开始
                $total=count($sources);
                $pageindex=max($_GPC['page'],1);
                $pagesize=2;
                $pager=pagination($total,$pageindex,$pagesize);
                $p=($pageindex-1)*2;
                $sql.=" order by id desc limit ".$p." , ".$pagesize;
                $jokelist=pdo_fetchall($sql);
		
		
		include $this->template('list');
	}
	
	//添加笑话的方法
	public function doWebAdd(){
		global $_W,$_GPC;
		if($_POST){
			//添加一条用户记录，并判断是否成功
			$article_data = array(
				'title' => $_GPC['title'],
				'content' => $_GPC['content'],
				'createtime'=>time(),
			);
			$result = pdo_insert(pig_joke_article, $article_data);
			if (!empty($result)) {
				
				message('添加成功',$this->createWebUrl('Joke'),'success');
			}else{
				message('添加失败',$this->createWebUrl('Joke'),'error');
			}
		}
		
		include $this->template('add');
	}
	

}