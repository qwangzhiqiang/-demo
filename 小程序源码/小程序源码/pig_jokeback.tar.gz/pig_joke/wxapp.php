<?php
/**
 * pig_joke模块小程序接口定义
 *
 * @author bendilaosiji
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Pig_jokeModuleWxapp extends WeModuleWxapp {
	public function doPageTest(){
		global $_GPC, $_W;
		$errno = 0;
		$message = '返回消息';
		$data = array();
		return $this->result($errno, $message, $data);
	}
	
	public function doPageIndex(){
		global $_GPC, $_W;
		$article = pdo_getall('pig_joke_article');
		$this->result(0, '获取数据成功', array('list' =>$article));
	}
	
}