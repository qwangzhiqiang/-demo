<?php
/**
 * pig_joke模块定义
 *
 * @author bendilaosiji
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Pig_jokeModule extends WeModule {



}