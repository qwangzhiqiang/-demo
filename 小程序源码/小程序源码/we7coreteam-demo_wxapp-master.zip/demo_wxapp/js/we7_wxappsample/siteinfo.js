var siteinfo = {
  "name": 'we7_wxappdemo',
  "uniacid": "944",
  "acid": "944",
  "multiid": "0",
  "version": "1.0.0",
  "siteroot": "http://www.fan.cc/app/index.php",
  'method_design': '3'
};
module.exports = siteinfo;    

