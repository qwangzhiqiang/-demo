//app.js
App({
  globalData:{
    appkey:'c39621ea5b825547001f9858a643f182',
    pagesize:10,
  }
})