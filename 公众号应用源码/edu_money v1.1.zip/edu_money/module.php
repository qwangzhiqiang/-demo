<?php
/**
 * 知识付费系统模块定义
 *
 * @author bendilaosiji
 * @url http://wqtest.bendilaosiji.com/
 */
defined('IN_IA') or exit('Access Denied');

class Edu_moneyModule extends WeModule {



}