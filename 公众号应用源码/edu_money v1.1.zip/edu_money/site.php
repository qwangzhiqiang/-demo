<?php
/**
 * 知识付费系统模块微站定义
 *
 * @author bendilaosiji
 * @url http://wqtest.bendilaosiji.com/
 */
defined('IN_IA') or exit('Access Denied');

class Edu_moneyModuleSite extends WeModuleSite {

	public function doMobileIndex() {
		//这个操作被定义用来呈现 功能封面
	}
	public function doWebCourses() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebUsers() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebOrders() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebConfigs() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}

}